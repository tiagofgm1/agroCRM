import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Users, 
  Plus, 
  Search, 
  Thermometer, 
  DollarSign, 
  MapPin, 
  Camera,
  LogOut,
  Bell,
  Filter,
  Tractor
} from 'lucide-react'
import { useNavigate } from 'react-router-dom'

const VendedorDashboard = ({ user, onLogout }) => {
  const navigate = useNavigate()
  const [clientes, setClientes] = useState([
    {
      id: 1,
      nome: 'João Silva',
      telefone: '(11) 99999-9999',
      cidade: 'Ribeirão Preto',
      area: 500,
      temperatura: 'Quente',
      valor: 250000,
      status: 'Negociação',
      pendencias: 2
    },
    {
      id: 2,
      nome: 'Maria Santos',
      telefone: '(16) 88888-8888',
      cidade: 'Sertãozinho',
      area: 300,
      temperatura: 'Morna',
      valor: 150000,
      status: 'Início de Relacionamento',
      pendencias: 1
    }
  ])
  const [filtro, setFiltro] = useState('')
  const [temperaturaFiltro, setTemperaturaFiltro] = useState('Todas')

  const getTemperaturaColor = (temp) => {
    switch (temp) {
      case 'Quente': return 'bg-red-100 text-red-800'
      case 'Morna': return 'bg-yellow-100 text-yellow-800'
      case 'Fria': return 'bg-blue-100 text-blue-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'Início de Relacionamento': return 'bg-blue-100 text-blue-800'
      case 'Negociação': return 'bg-orange-100 text-orange-800'
      case 'Faturamento': return 'bg-purple-100 text-purple-800'
      case 'Pedido Faturado': return 'bg-green-100 text-green-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const clientesFiltrados = clientes.filter(cliente => {
    const matchNome = cliente.nome.toLowerCase().includes(filtro.toLowerCase())
    const matchTelefone = cliente.telefone.includes(filtro)
    const matchTemperatura = temperaturaFiltro === 'Todas' || cliente.temperatura === temperaturaFiltro
    return (matchNome || matchTelefone) && matchTemperatura
  })

  const totalValor = clientes.reduce((sum, cliente) => sum + cliente.valor, 0)
  const clientesQuentes = clientes.filter(c => c.temperatura === 'Quente').length

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Tractor className="h-8 w-8 text-green-600 mr-3" />
              <div>
                <h1 className="text-xl font-semibold text-gray-900">AgroCRM</h1>
                <p className="text-sm text-gray-500">Olá, {user.nome}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={onLogout}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Cards de Resumo */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Clientes</p>
                  <p className="text-2xl font-bold text-gray-900">{clientes.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Thermometer className="h-8 w-8 text-red-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Negócios Quentes</p>
                  <p className="text-2xl font-bold text-gray-900">{clientesQuentes}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <DollarSign className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Valor Total</p>
                  <p className="text-2xl font-bold text-gray-900">
                    R$ {totalValor.toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Bell className="h-8 w-8 text-orange-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Pendências</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {clientes.reduce((sum, c) => sum + c.pendencias, 0)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filtros e Busca */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <CardTitle>Meus Clientes</CardTitle>
                <CardDescription>Gerencie seus clientes e oportunidades</CardDescription>
              </div>
              <Button 
                onClick={() => navigate('/cliente')}
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Novo Cliente
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Buscar por nome ou telefone..."
                    value={filtro}
                    onChange={(e) => setFiltro(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                {['Todas', 'Quente', 'Morna', 'Fria'].map((temp) => (
                  <Button
                    key={temp}
                    variant={temperaturaFiltro === temp ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setTemperaturaFiltro(temp)}
                  >
                    {temp}
                  </Button>
                ))}
              </div>
            </div>

            {/* Lista de Clientes */}
            <div className="space-y-4">
              {clientesFiltrados.map((cliente) => (
                <Card key={cliente.id} className="hover:shadow-md transition-shadow cursor-pointer">
                  <CardContent className="p-6">
                    <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-lg font-semibold text-gray-900">{cliente.nome}</h3>
                          <Badge className={getTemperaturaColor(cliente.temperatura)}>
                            {cliente.temperatura}
                          </Badge>
                          <Badge className={getStatusColor(cliente.status)}>
                            {cliente.status}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm text-gray-600">
                          <div className="flex items-center">
                            <span className="font-medium">📞 {cliente.telefone}</span>
                          </div>
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            <span>{cliente.cidade}</span>
                          </div>
                          <div className="flex items-center">
                            <span>🌾 {cliente.area} hectares</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-green-600">
                          R$ {cliente.valor.toLocaleString('pt-BR')}
                        </p>
                        {cliente.pendencias > 0 && (
                          <p className="text-sm text-orange-600">
                            {cliente.pendencias} pendência(s)
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex justify-end mt-4 gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => navigate(`/cliente/${cliente.id}`)}
                      >
                        Editar
                      </Button>
                      <Button variant="outline" size="sm">
                        <Camera className="h-4 w-4 mr-1" />
                        Fotos
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {clientesFiltrados.length === 0 && (
              <div className="text-center py-8">
                <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Nenhum cliente encontrado</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default VendedorDashboard

