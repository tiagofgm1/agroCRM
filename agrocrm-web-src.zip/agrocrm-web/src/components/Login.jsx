import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Tractor, Users, BarChart3 } from 'lucide-react'

const Login = ({ onLogin }) => {
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')

  const handleLogin = (tipo) => {
    if (email && senha) {
      onLogin({
        id: Date.now(),
        nome: email.split('@')[0],
        email,
        tipo
      })
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        {/* Logo e Header */}
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <div className="bg-green-600 p-3 rounded-full">
              <Tractor className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-gray-900">AgroCRM Mobile</h1>
          <p className="text-gray-600 mt-2">Gestão Comercial Agrícola</p>
        </div>

        {/* Formulário de Login */}
        <Card>
          <CardHeader>
            <CardTitle>Acesso ao Sistema</CardTitle>
            <CardDescription>
              Entre com suas credenciais para acessar o sistema
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="vendedor" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="vendedor" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Vendedor
                </TabsTrigger>
                <TabsTrigger value="gerente" className="flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  Gerente
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="vendedor" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="email-vendedor">Email</Label>
                  <Input
                    id="email-vendedor"
                    type="email"
                    placeholder="vendedor@empresa.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="senha-vendedor">Senha</Label>
                  <Input
                    id="senha-vendedor"
                    type="password"
                    placeholder="••••••••"
                    value={senha}
                    onChange={(e) => setSenha(e.target.value)}
                  />
                </div>
                <Button 
                  className="w-full bg-green-600 hover:bg-green-700"
                  onClick={() => handleLogin('vendedor')}
                >
                  Entrar como Vendedor
                </Button>
              </TabsContent>
              
              <TabsContent value="gerente" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="email-gerente">Email</Label>
                  <Input
                    id="email-gerente"
                    type="email"
                    placeholder="gerente@empresa.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="senha-gerente">Senha</Label>
                  <Input
                    id="senha-gerente"
                    type="password"
                    placeholder="••••••••"
                    value={senha}
                    onChange={(e) => setSenha(e.target.value)}
                  />
                </div>
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  onClick={() => handleLogin('gerente')}
                >
                  Entrar como Gerente
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Recursos do Sistema */}
        <div className="grid grid-cols-1 gap-4 text-sm">
          <div className="bg-white p-4 rounded-lg shadow-sm border">
            <h3 className="font-semibold text-green-700 mb-2">🌾 Para Vendedores</h3>
            <p className="text-gray-600">Gerencie clientes, negociações e oportunidades agrícolas</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm border">
            <h3 className="font-semibold text-blue-700 mb-2">📊 Para Gerentes</h3>
            <p className="text-gray-600">Acompanhe equipe, relatórios e faça apontamentos</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Login

