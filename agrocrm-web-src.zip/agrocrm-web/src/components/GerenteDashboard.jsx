import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { 
  Users, 
  BarChart3, 
  DollarSign, 
  TrendingUp,
  MessageSquare,
  LogOut,
  Bell,
  Tractor,
  Target,
  AlertCircle,
  CheckCircle
} from 'lucide-react'

const GerenteDashboard = ({ user, onLogout }) => {
  const [vendedores] = useState([
    {
      id: 1,
      nome: 'João Vendedor',
      email: 'joao@empresa.com',
      clientes: 15,
      valorTotal: 750000,
      clientesQuentes: 5,
      pendencias: 3,
      ultimaAtividade: '2 horas atrás'
    },
    {
      id: 2,
      nome: 'Maria Vendedora',
      telefone: 'maria@empresa.com',
      clientes: 12,
      valorTotal: 480000,
      clientesQuentes: 3,
      pendencias: 1,
      ultimaAtividade: '1 hora atrás'
    }
  ])

  const [apontamentos, setApontamentos] = useState([
    {
      id: 1,
      vendedorId: 1,
      clienteNome: 'João Silva',
      mensagem: 'Precisa atualizar o valor da proposta e agendar visita técnica',
      data: new Date(),
      status: 'pendente'
    }
  ])

  const [novoApontamento, setNovoApontamento] = useState('')
  const [vendedorSelecionado, setVendedorSelecionado] = useState(null)

  const adicionarApontamento = () => {
    if (novoApontamento && vendedorSelecionado) {
      const apontamento = {
        id: Date.now(),
        vendedorId: vendedorSelecionado,
        mensagem: novoApontamento,
        data: new Date(),
        status: 'pendente'
      }
      setApontamentos([...apontamentos, apontamento])
      setNovoApontamento('')
      setVendedorSelecionado(null)
    }
  }

  const totalClientes = vendedores.reduce((sum, v) => sum + v.clientes, 0)
  const totalValor = vendedores.reduce((sum, v) => sum + v.valorTotal, 0)
  const totalQuentes = vendedores.reduce((sum, v) => sum + v.clientesQuentes, 0)
  const totalPendencias = vendedores.reduce((sum, v) => sum + v.pendencias, 0)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Tractor className="h-8 w-8 text-blue-600 mr-3" />
              <div>
                <h1 className="text-xl font-semibold text-gray-900">AgroCRM - Gestão</h1>
                <p className="text-sm text-gray-500">Olá, {user.nome} (Gerente)</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={onLogout}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Cards de Resumo Geral */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Clientes</p>
                  <p className="text-2xl font-bold text-gray-900">{totalClientes}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Target className="h-8 w-8 text-red-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Negócios Quentes</p>
                  <p className="text-2xl font-bold text-gray-900">{totalQuentes}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <DollarSign className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Valor Total Pipeline</p>
                  <p className="text-2xl font-bold text-gray-900">
                    R$ {totalValor.toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <AlertCircle className="h-8 w-8 text-orange-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Pendências</p>
                  <p className="text-2xl font-bold text-gray-900">{totalPendencias}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="vendedores" className="space-y-6">
          <TabsList>
            <TabsTrigger value="vendedores">Equipe de Vendas</TabsTrigger>
            <TabsTrigger value="apontamentos">Apontamentos</TabsTrigger>
            <TabsTrigger value="relatorios">Relatórios</TabsTrigger>
          </TabsList>

          {/* Aba Vendedores */}
          <TabsContent value="vendedores">
            <Card>
              <CardHeader>
                <CardTitle>Equipe de Vendas</CardTitle>
                <CardDescription>
                  Acompanhe o desempenho e atividades dos vendedores
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {vendedores.map((vendedor) => (
                    <Card key={vendedor.id} className="border-l-4 border-l-blue-500">
                      <CardContent className="p-6">
                        <div className="flex flex-col lg:flex-row justify-between items-start gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-3">
                              <h3 className="text-lg font-semibold text-gray-900">
                                {vendedor.nome}
                              </h3>
                              <Badge variant="outline">{vendedor.email}</Badge>
                            </div>
                            
                            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                              <div>
                                <p className="text-gray-600">Clientes</p>
                                <p className="font-semibold text-lg">{vendedor.clientes}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Negócios Quentes</p>
                                <p className="font-semibold text-lg text-red-600">
                                  {vendedor.clientesQuentes}
                                </p>
                              </div>
                              <div>
                                <p className="text-gray-600">Valor Total</p>
                                <p className="font-semibold text-lg text-green-600">
                                  R$ {vendedor.valorTotal.toLocaleString('pt-BR')}
                                </p>
                              </div>
                              <div>
                                <p className="text-gray-600">Pendências</p>
                                <p className="font-semibold text-lg text-orange-600">
                                  {vendedor.pendencias}
                                </p>
                              </div>
                            </div>
                            
                            <p className="text-sm text-gray-500 mt-3">
                              Última atividade: {vendedor.ultimaAtividade}
                            </p>
                          </div>
                          
                          <div className="flex gap-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => setVendedorSelecionado(vendedor.id)}
                            >
                              <MessageSquare className="h-4 w-4 mr-1" />
                              Apontamento
                            </Button>
                            <Button variant="outline" size="sm">
                              <BarChart3 className="h-4 w-4 mr-1" />
                              Relatório
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Aba Apontamentos */}
          <TabsContent value="apontamentos">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Novo Apontamento */}
              <Card>
                <CardHeader>
                  <CardTitle>Novo Apontamento</CardTitle>
                  <CardDescription>
                    Envie orientações e cobranças para os vendedores
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Vendedor</label>
                    <select 
                      className="w-full mt-1 p-2 border rounded-md"
                      value={vendedorSelecionado || ''}
                      onChange={(e) => setVendedorSelecionado(Number(e.target.value))}
                    >
                      <option value="">Selecione um vendedor</option>
                      {vendedores.map((v) => (
                        <option key={v.id} value={v.id}>{v.nome}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Mensagem</label>
                    <Textarea
                      placeholder="Digite sua orientação ou cobrança..."
                      value={novoApontamento}
                      onChange={(e) => setNovoApontamento(e.target.value)}
                      className="mt-1"
                      rows={4}
                    />
                  </div>
                  <Button 
                    onClick={adicionarApontamento}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    disabled={!novoApontamento || !vendedorSelecionado}
                  >
                    Enviar Apontamento
                  </Button>
                </CardContent>
              </Card>

              {/* Lista de Apontamentos */}
              <Card>
                <CardHeader>
                  <CardTitle>Apontamentos Recentes</CardTitle>
                  <CardDescription>
                    Histórico de orientações enviadas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {apontamentos.map((apontamento) => {
                      const vendedor = vendedores.find(v => v.id === apontamento.vendedorId)
                      return (
                        <div key={apontamento.id} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-sm">
                              Para: {vendedor?.nome}
                            </span>
                            <Badge 
                              variant={apontamento.status === 'pendente' ? 'destructive' : 'default'}
                            >
                              {apontamento.status === 'pendente' ? 'Pendente' : 'Visualizado'}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">
                            {apontamento.mensagem}
                          </p>
                          <p className="text-xs text-gray-500">
                            {apontamento.data.toLocaleString('pt-BR')}
                          </p>
                        </div>
                      )
                    })}
                    
                    {apontamentos.length === 0 && (
                      <div className="text-center py-8">
                        <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-500">Nenhum apontamento enviado</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Aba Relatórios */}
          <TabsContent value="relatorios">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Resumo por Vendedor</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {vendedores.map((vendedor) => (
                      <div key={vendedor.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="font-medium">{vendedor.nome}</span>
                        <div className="text-right">
                          <p className="font-semibold text-green-600">
                            R$ {vendedor.valorTotal.toLocaleString('pt-BR')}
                          </p>
                          <p className="text-sm text-gray-600">
                            {vendedor.clientes} clientes
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Métricas Gerais</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Taxa de Conversão</span>
                      <span className="font-semibold">
                        {((totalQuentes / totalClientes) * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Ticket Médio</span>
                      <span className="font-semibold">
                        R$ {(totalValor / totalClientes).toLocaleString('pt-BR')}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Clientes por Vendedor</span>
                      <span className="font-semibold">
                        {(totalClientes / vendedores.length).toFixed(1)}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default GerenteDashboard

